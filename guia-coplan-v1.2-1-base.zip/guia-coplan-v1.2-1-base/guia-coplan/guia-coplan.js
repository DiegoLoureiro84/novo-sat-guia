/*!
 * Guia Coplan v1.0
 * Roteiros guiados e ajuda por tela para aplicações web GeneXus.
 * Não altera nenhum objeto GeneXus: só lê a página já renderizada.
 * Depende de Driver.js 1.8.0 (licença MIT), carregado antes deste arquivo.
 *
 * Histórico
 *  v0.1  prova de conceito (Diego Loureiro).
 *  v0.1b aplicado no GeneXus 16, KB do Tributário, por Bruno Marchetto: Select2, lupa de
 *        consulta, passos ocultos, controle recriado pelo AJAX, foco no campo, reposicionamento.
 *  v1.2  passo a passo automático: gerado da tela, sem ninguém escrever roteiro.
 *        Roteiros escritos (pasta ou tabela) viram camada opcional por cima.
 *  v1.1  manual automático: monta o manual da tela na hora, lendo a tela e os roteiros.
 *  v1.0  sobre a versão do Bruno:
 *        - roteiro em pasta (um JSON por tela) OU em tabela do banco (Procedure HTTP), sem deploy;
 *        - "alvo" aceita lista de seletores (ex.: "#W0003vCAMPO" e "[id$='vCAMPO']");
 *        - vários roteiros por tela ({ "roteiros": [ ... ] });
 *        - retoma o roteiro se a página recarregar (ex.: evento que faz postback);
 *        - passo "opcional";
 *        - modo autor: monta o roteiro clicando nos campos e exporta o JSON;
 *        - textos tratados como texto puro (só <b> <strong> <i> <em> <u> <br>);
 *        - GuiaCoplan.testar(), GuiaCoplan.recarregar(), GuiaCoplan.autor().
 */
(function (w, d) {
  'use strict';

  var VERSAO = '1.2';
  var CFG = {};
  var roteirosTela = [];     // roteiros disponíveis na tela atual
  var roteiroAtual = null;   // roteiro em execução (ou o primeiro da tela)
  var idxRoteiro = 0;
  var telaCarregada = null;
  var driverObj = null;
  var botao = null;
  var passoOk = {};          // índice do passo -> ação exigida já foi feita
  var observador = null;
  var aoTerminar = null;     // callback usado pelo modo autor ao testar
  var CHAVE_ESTADO = 'guiaCoplanEstado';

  var PADRAO = {
    // Onde buscar o roteiro de cada tela. Aceita texto ou lista (tenta na ordem, usa o primeiro que achar).
    //  - pasta:     '/app/static/guia-coplan/roteiros/'             -> busca <pasta><tela>.json
    //  - endpoint:  '/app/servlet/com.app.aguiaroteiroobter?tela={tela}' -> {tela} é trocado pelo nome da tela
    roteirosUrl: 'guia-coplan/roteiros/',
    roteiros: null,          // alternativa: objeto { "nome-da-tela": {roteiro ou pacote} } já embutido
    manualUrl: null,         // manual escrito (opcional), ex.: 'https://manual.exemplo/novo-sat/#{tela}'
    roteiroAuto: true,       // passo a passo automático: gerado da tela, sem roteiro escrito
    manualAuto: true,        // manual automático: montado na hora a partir da tela e dos roteiros
    manualRaiz: null,        // seletor da área de conteúdo a ler (ex.: o conteúdo da Master Page); null = página toda
    manualIgnorar: 'header, nav, [role=navigation], .guia-coplan, .guia-autor, .guia-manual, .driver-popover', // áreas que não entram no manual
    tela: null,              // força o nome da tela (senão é deduzido da URL)
    montarBotaoEm: null,     // seletor onde o botão ? é inserido; vazio = botão flutuante
    registrar: null,         // function (evento) {...} para guardar evidência de uso
    onAbrirManual: null,     // function (url, roteiro) {...}; padrão abre nova aba
    autor: false,            // true = mostra "Criar roteiro desta tela" no menu (só em desenvolvimento)
    retomarMinutos: 2,       // retoma o roteiro se a mesma tela recarregar dentro deste prazo (postback); 0 = desliga
    debug: false
  };

  /* ---------- utilitários ---------- */
  function log() { if (CFG.debug && w.console) console.log.apply(console, ['[guia-coplan]'].concat([].slice.call(arguments))); }
  function q(sel) { try { return sel ? d.querySelector(sel) : null; } catch (e) { return null; } }
  function qa(sel) { try { return sel ? d.querySelectorAll(sel) : []; } catch (e) { return []; } }
  function el(tag, cls, html) { var e = d.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }
  function ehLista(x) { return Object.prototype.toString.call(x) === '[object Array]'; }

  /* "alvo" pode ser um seletor ou uma lista de seletores: usa o primeiro que existir na tela.
     Ex.: ["#W0003vNFSE_TOMADOR_EMAIL", "[id$='vNFSE_TOMADOR_EMAIL']"] continua funcionando
     se o Web Component mudar de W0003 para W0004. */
  function seletor(alvo) {
    if (!alvo) return null;
    if (!ehLista(alvo)) return alvo;
    for (var i = 0; i < alvo.length; i++) { if (q(alvo[i])) return alvo[i]; }
    return alvo[0] || null;
  }

  function registrar(evento, extra) {
    var dados = { evento: evento, tela: telaCarregada, roteiro: roteiroAtual && roteiroAtual.titulo, quando: new Date().toISOString() };
    for (var k in (extra || {})) dados[k] = extra[k];
    log(dados);
    if (typeof CFG.registrar === 'function') { try { CFG.registrar(dados); } catch (e) {} }
  }

  function aviso(html, ms) {
    var t = el('div', 'guia-coplan__toast', html);
    d.body.appendChild(t);
    setTimeout(function () { t.remove(); }, ms || 3500);
    return t;
  }

  /* Deduz o nome do objeto GeneXus pela URL.
     .NET:  /novosat/wpparcelamento.aspx               -> wpparcelamento
     Java:  /tributario/servlet/com.tributario.tnota   -> tnota
     Rota:  /tributario/sinop/tnota_padrao_nacional    -> tnota_padrao_nacional */
  function telaAtual() {
    if (CFG.tela) return String(CFG.tela).toLowerCase();
    var ult = (w.location.pathname.split('/').pop() || '').replace(/\.(aspx|html?)$/i, '');
    return ult.split('.').pop().toLowerCase();
  }

  /* ---------- leitura do roteiro ---------- */
  /* Aceita a resposta em vários formatos e devolve SEMPRE uma lista de roteiros (ou null):
     - um roteiro { titulo, passos: [...] }
     - um pacote { roteiros: [ {titulo, passos}, ... ] }  (vários roteiros na mesma tela)
     - texto JSON, inclusive JSON dentro de texto (comum quando vem de LongVarChar), com ou sem BOM
     - envelope com uma única propriedade, ex.: { "Json": "..." } (retorno típico de REST GeneXus)
     - "null", vazio ou 404 = tela sem roteiro */
  function interpretar(r, nivel) {
    nivel = nivel || 0;
    if (r == null || nivel > 4) return null;
    if (typeof r === 'string') {
      var t = r.replace(/^﻿/, '').trim();
      if (!t || t === 'null') return null;
      try { return interpretar(JSON.parse(t), nivel + 1); } catch (e) { log('resposta não é JSON', e); return null; }
    }
    if (ehLista(r)) {
      var lista = [];
      for (var i = 0; i < r.length; i++) { var x = interpretar(r[i], nivel + 1); if (x) lista = lista.concat(x); }
      return lista.length ? lista : null;
    }
    if (typeof r === 'object') {
      if (r.passos && r.passos.length) { var um = [r]; if (r.ajuda) um.ajuda = r.ajuda; return um; }
      if (ehLista(r.roteiros)) { var v = interpretar(r.roteiros, nivel + 1); if (v && r.ajuda) v.ajuda = r.ajuda; return v; }
      var chaves = Object.keys(r);
      if (chaves.length === 1) return interpretar(r[chaves[0]], nivel + 1);
    }
    return null;
  }

  function urlDoRoteiro(base, tela) {
    var t = encodeURIComponent(tela);
    return base.indexOf('{tela}') >= 0 ? base.replace(/\{tela\}/g, t) : base + t + '.json';
  }

  function buscar(url) {
    return fetch(url, { cache: 'no-cache', credentials: 'same-origin' })
      .then(function (r) { return r.ok ? r.text() : null; })
      .then(function (txt) { return interpretar(txt); })
      .catch(function (e) { log('falha ao buscar', url, e); return null; });
  }

  function carregarRoteiros(tela) {
    if (CFG.roteiros) return Promise.resolve(interpretar(CFG.roteiros[tela]));
    var fontes = [].concat(CFG.roteirosUrl || []);
    var i = 0;
    function proxima() {
      if (i >= fontes.length) return Promise.resolve(null);
      var url = urlDoRoteiro(fontes[i++], tela);
      return buscar(url).then(function (r) { if (r) { log('roteiro de', url); return r; } return proxima(); });
    }
    return proxima();
  }

  /* Texto do balão: tudo é tratado como texto puro, exceto estas marcações simples.
     Evita que um roteiro cadastrado no banco injete script na tela de todos os usuários. */
  var TAGS_LIVRES = /&lt;(\/?)(b|strong|i|em|u|br)\s*\/?&gt;/gi;
  function textoSeguro(s) {
    if (s == null) return '';
    return String(s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;')
      .replace(TAGS_LIVRES, function (m, barra, tag) { return '<' + barra + tag.toLowerCase() + '>'; });
  }

  /* ---------- retomar após recarga da página ---------- */
  function salvarEstado(passo) {
    if (!CFG.retomarMinutos) return;
    try { w.sessionStorage.setItem(CHAVE_ESTADO, JSON.stringify({ tela: telaCarregada, roteiro: idxRoteiro, passo: passo, quando: Date.now() })); } catch (e) {}
  }
  function limparEstado() { try { w.sessionStorage.removeItem(CHAVE_ESTADO); } catch (e) {} }
  function lerEstado() {
    if (!CFG.retomarMinutos) return null;
    try {
      var s = JSON.parse(w.sessionStorage.getItem(CHAVE_ESTADO) || 'null');
      if (s && s.tela === telaCarregada && Date.now() - s.quando < CFG.retomarMinutos * 60000) return s;
    } catch (e) {}
    return null;
  }

  /* ---------- condição de "esperar" ---------- */
  // tipos: "clique" | "preenchido" | "marcado"
  function condicaoAtendida(p, i) {
    var e = p.esperar;
    if (!e) return true;
    if (e.tipo === 'clique') return !!passoOk[i];
    var itens = qa(seletor(e.alvo || p.alvo));
    for (var k = 0; k < itens.length; k++) {
      if (e.tipo === 'marcado' && itens[k].checked) return true;
      if (e.tipo === 'preenchido' && String(itens[k].value || '').trim() !== '') return true;
    }
    return false;
  }

  function atualizarPopover() {
    if (!driverObj || !driverObj.isActive() || !roteiroAtual) return;
    var i = driverObj.getActiveIndex();
    var p = roteiroAtual.passos[i];
    var pop = driverObj.getState('popover');
    if (!p || !pop) return;
    var ok = condicaoAtendida(p, i);
    pop.nextButton.disabled = !ok;
    pop.nextButton.classList.toggle('guia-desabilitado', !ok);
    var av = pop.description.querySelector('.guia-aviso');
    if (!ok && !av && p.esperar) {
      pop.description.appendChild(el('span', 'guia-aviso', textoSeguro(p.esperar.mensagem || 'Execute a ação indicada para continuar.')));
    } else if (ok && av) {
      av.remove();
    }
  }

  // Delegação no document: sobrevive aos re-renders que o GeneXus faz via AJAX.
  function ouvirAcoes(ev) {
    if (!driverObj || !driverObj.isActive() || !roteiroAtual) return;
    var i = driverObj.getActiveIndex();
    var p = roteiroAtual.passos[i];
    if (!p || !p.esperar) return;
    var alvo = seletor(p.esperar.alvo || p.alvo);
    var casou = false;
    try { casou = !!(ev.target.closest && ev.target.closest(alvo)); } catch (e) {}
    if (!casou) return;
    if (p.esperar.tipo === 'clique' && ev.type === 'click') {
      passoOk[i] = true;
      registrar('acao_executada', { passo: i + 1 });
      var prox = vizinhoVisivel(i, 1);
      // se o clique fizer a página recarregar, o roteiro volta no próximo passo
      if (prox < 0) limparEstado(); else salvarEstado(prox);
      // dá tempo para o evento GeneXus rodar e a tela se atualizar
      setTimeout(function () { if (driverObj && driverObj.isActive() && driverObj.getActiveIndex() === i) {
        var px = vizinhoVisivel(i, 1);
        if (px < 0) { registrar('roteiro_concluido', { passos: roteiroAtual.passos.length }); driverObj.destroy(); } else driverObj.moveTo(px);
      } }, 600);
      return;
    }
    if (!passoOk[i] && condicaoAtendida(p, i)) { passoOk[i] = true; registrar('acao_executada', { passo: i + 1 }); }
    atualizarPopover();
  }

  /* Passo visível = sem alvo (mensagem central) ou alvo presente e realmente exibido na tela. */
  function passoVisivel(p) {
    if (!p.alvo) return true;
    var e = q(seletor(p.alvo));
    if (!e) return false;
    if (!(e.offsetWidth || e.offsetHeight || e.getClientRects().length)) return false;
    var cs = w.getComputedStyle(e);
    return cs.visibility !== 'hidden' && cs.display !== 'none';
  }

  // Índice do próximo (dir=1) ou anterior (dir=-1) passo visível; -1 se não houver.
  function vizinhoVisivel(atual, dir) {
    var passos = roteiroAtual.passos;
    for (var k = atual + dir; k >= 0 && k < passos.length; k += dir) {
      if (passoVisivel(passos[k])) return k;
    }
    return -1;
  }

  /* Resolve o elemento a destacar. Campos com lupa de consulta (prompt do GeneXus) têm um
     <a class="gx-image-link"> ao lado do input: nesse caso destaca o container que envolve
     campo + lupa, para os dois ficarem numa única área em destaque e clicável. */
  function resolverAlvo(alvo) {
    var e = q(seletor(alvo));
    if (!e || !e.parentNode || !/^(INPUT|SELECT|TEXTAREA)$/.test(e.tagName)) return e;
    var pai = e.parentNode;
    if (pai.querySelector('a.gx-image-link') && !pai.querySelector('table')) return pai;
    return e;
  }

  /* Coloca o cursor no campo do passo (o Driver.js foca o botão "Próximo" por padrão, por isso o atraso). */
  function focarCampo(elemento) {
    if (!elemento || !driverObj || !driverObj.isActive()) return;
    var alvo = null;
    var campo = /^(INPUT|SELECT|TEXTAREA)$/.test(elemento.tagName) ? elemento : elemento.querySelector('input:not([type=hidden]),select,textarea');
    if (campo && campo.type !== 'button' && !campo.disabled && !campo.readOnly) alvo = campo;
    else {
      // Select2: o alvo é o container; foca a seleção visível
      var s2 = elemento.closest && elemento.closest('.select2-selection');
      if (s2) alvo = s2;
    }
    if (alvo && alvo.focus) { try { alvo.focus(); } catch (e) {} }
  }

  /* ---------- roteiro ---------- */
  // iniciarRoteiro()                      -> primeiro roteiro da tela
  // iniciarRoteiro(1)                     -> segundo roteiro da tela
  // iniciarRoteiro({titulo, passos})      -> roteiro informado (usado por testar e pelo modo autor)
  function iniciarRoteiro(roteiro, passoInicial) {
    if (typeof roteiro === 'string' && roteiro.indexOf('auto:') === 0) { idxRoteiro = roteiro; roteiro = roteiroAutomatico(roteiro === 'auto:o'); if (!roteiro.passos.length) { aviso('Nenhum campo encontrado nesta tela.'); return; } }
    else if (typeof roteiro === 'number') { idxRoteiro = roteiro; roteiro = roteirosTela[roteiro]; }
    else if (roteiro) { var achou = roteirosTela.indexOf(roteiro); idxRoteiro = achou >= 0 ? achou : -1; }
    else { idxRoteiro = 0; roteiro = roteirosTela[0]; }
    if (roteiro) roteiroAtual = roteiro;
    if (!roteiroAtual) return;
    var criar = w.driver && w.driver.js && w.driver.js.driver;
    if (!criar) { console.error('[guia-coplan] Driver.js não foi carregado antes do guia-coplan.js'); return; }
    if (driverObj && driverObj.isActive()) driverObj.destroy();
    passoOk = {};
    var total = roteiroAtual.passos.length;
    driverObj = criar({
      showProgress: true,
      progressText: 'Passo {{current}} de {{total}}',
      nextBtnText: 'Próximo',
      prevBtnText: 'Voltar',
      doneBtnText: 'Concluir',
      popoverClass: 'guia-coplan-popover',
      overlayOpacity: 0.55,
      stageRadius: 12,
      waitForElement: 4000,        // espera o GeneXus desenhar o controle (AJAX)
      allowClose: true,
      overlayClickBehavior: function () {}, // clicar fora do campo não encerra o guia (só o X ou Esc)
      disableActiveInteraction: false,      // mantém o campo destacado clicável
      steps: roteiroAtual.passos.map(function (p) {
        var titulo = (p.opcional ? '<span class="guia-opcional">Opcional</span> ' : '') + textoSeguro(p.titulo);
        return {
          element: p.alvo ? function () { return resolverAlvo(p.alvo); } : undefined,
          popover: { title: titulo, description: textoSeguro(p.texto), side: p.lado || 'bottom', align: 'start' }
        };
      }),
      onPopoverRender: function () { setTimeout(atualizarPopover, 0); },
      // salva no início do destaque (não no fim da animação): se a página recarregar logo
      // depois de um clique, o passo atual já está guardado
      onHighlightStarted: function (elemento, passo, opcoes) {
        var i = opcoes && opcoes.state && typeof opcoes.state.activeIndex === 'number' ? opcoes.state.activeIndex : driverObj.getActiveIndex();
        if (idxRoteiro !== -1 && typeof i === 'number') salvarEstado(i);
      },
      onHighlighted: function (elemento) {
        setTimeout(function () { focarCampo(elemento); }, 80);
        // reforça o posicionamento depois que o scroll e o layout assentam
        [150, 500].forEach(function (ms) {
          setTimeout(function () { if (driverObj && driverObj.isActive()) driverObj.refresh(); }, ms);
        });
      },
      onNextClick: function () {
        var i = driverObj.getActiveIndex();
        if (!condicaoAtendida(roteiroAtual.passos[i], i)) { atualizarPopover(); return; }
        registrar('passo_concluido', { passo: i + 1 });
        var prox = vizinhoVisivel(i, 1);
        if (prox < 0) { registrar('roteiro_concluido', { passos: total }); driverObj.destroy(); }
        else driverObj.moveTo(prox);
      },
      onPrevClick: function () {
        var ant = vizinhoVisivel(driverObj.getActiveIndex(), -1);
        if (ant >= 0) driverObj.moveTo(ant);
      },
      onCloseClick: function () {
        registrar('roteiro_interrompido', { passo: driverObj.getActiveIndex() + 1 });
        driverObj.destroy();
      },
      onDestroyed: function () {
        limparEstado();
        if (typeof aoTerminar === 'function') { var f = aoTerminar; aoTerminar = null; f(); }
      }
    });
    var inicio = passoInicial || 0;
    if (!passoVisivel(roteiroAtual.passos[inicio] || {})) {
      var v = vizinhoVisivel(inicio, 1);
      inicio = v >= 0 ? v : 0;
    }
    registrar(passoInicial ? 'roteiro_retomado' : 'roteiro_iniciado', { passos: total, passo: inicio + 1 });
    driverObj.drive(inicio);
  }

  function abrirManual() {
    var r = roteiroAtual || roteirosTela[0];
    var url = CFG.manualUrl ? CFG.manualUrl.replace('{tela}', encodeURIComponent((r && r.manual) || telaCarregada)) : null;
    registrar('manual_aberto');
    if (typeof CFG.onAbrirManual === 'function') return CFG.onAbrirManual(url, r);
    if (url) w.open(url, '_blank', 'noopener');
  }

  /* ---------- botão ? ---------- */
  var ICONE_AJUDA = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><path d="M12 17h.01"/></svg>';
  var ICONE_ROTEIRO = '<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ><circle cx="6" cy="19" r="3" /><path d="M9 19h8.5a3.5 3.5 0 0 0 0-7h-11a3.5 3.5 0 0 1 0-7H15" /><circle cx="18" cy="5" r="3" /></svg>';
  var ICONE_MANUAL = '<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" ><path d="M12 5v16" /><path d="M20.001 19A2 2 0 0022 17V5a2 2 0 00-1.999-2L16 3.002A5 5 0 0012 5a5 5 0 00-4-2H4a2 2 0 00-2 2v12a2 2 0 001.999 2H8a5 5 0 014 2 5 5 0 014-2z" /></svg>';
  var ICONE_AUTOR = '<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.376 3.622a1 1 0 0 1 3.002 3.002L7.368 18.635a2 2 0 0 1-.855.506l-2.872.838a.5.5 0 0 1-.62-.62l.838-2.872a2 2 0 0 1 .506-.854z"/></svg>';

  function montarBotao() {
    if (botao) { botao.remove(); botao = null; }
    if (!roteirosTela.length && !CFG.manualUrl && !CFG.onAbrirManual && !CFG.autor && !CFG.manualAuto && !CFG.roteiroAuto) return;
    var host = CFG.montarBotaoEm ? q(CFG.montarBotaoEm) : null;
    botao = el('div', 'guia-coplan' + (host ? '' : ' guia-coplan--flutuante'));
    var btn = el('button', 'guia-coplan__botao', ICONE_AJUDA);
    btn.type = 'button';
    btn.id = 'guia-coplan-botao';
    btn.setAttribute('aria-label', 'Ajuda desta tela');
    btn.setAttribute('aria-expanded', 'false');
    var menu = el('div', 'guia-coplan__menu');
    menu.hidden = true;
    menu.appendChild(el('div', 'guia-coplan__menu-titulo', 'Ajuda desta tela'));
    roteirosTela.forEach(function (r, i) {
      var rotulo = (roteirosTela.length > 1 || CFG.roteiroAuto) ? textoSeguro(r.titulo || ('Roteiro ' + (i + 1))) : 'Me guie nesta tela';
      var b = el('button', null, ICONE_ROTEIRO + '<span></span>'); b.type = 'button';
      b.querySelector('span').innerHTML = rotulo;
      b.setAttribute('data-roteiro', String(i));
      b.onclick = function () { menu.hidden = true; iniciarRoteiro(i); };
      menu.appendChild(b);
    });
    if (CFG.roteiroAuto) {
      if (roteirosTela.length) menu.appendChild(el('div', 'guia-coplan__menu-titulo', 'Gerado da tela'));
      [['auto:o', 'Me guie: campos obrigatórios'], ['auto:t', 'Me guie: todos os campos']].forEach(function (x) {
        var ba = el('button', null, ICONE_ROTEIRO + x[1]); ba.type = 'button';
        ba.setAttribute('data-roteiro', x[0]);
        ba.onclick = function () { menu.hidden = true; iniciarRoteiro(x[0]); };
        menu.appendChild(ba);
      });
    }
    if (CFG.manualAuto) {
      var b4 = el('button', null, ICONE_MANUAL + 'Manual desta tela'); b4.type = 'button';
      b4.setAttribute('data-manual', 'auto');
      b4.onclick = function () { menu.hidden = true; manual(); };
      menu.appendChild(b4);
    }
    if (CFG.manualUrl || CFG.onAbrirManual) {
      var b2 = el('button', null, ICONE_MANUAL + (CFG.manualAuto ? 'Manual completo' : 'Abrir manual desta tela')); b2.type = 'button';
      b2.setAttribute('data-manual', 'escrito');
      b2.onclick = function () { menu.hidden = true; abrirManual(); };
      menu.appendChild(b2);
    }
    if (CFG.autor) {
      var b3 = el('button', null, ICONE_AUTOR + 'Criar roteiro desta tela'); b3.type = 'button';
      b3.onclick = function () { menu.hidden = true; autor(); };
      menu.appendChild(b3);
    }
    btn.onclick = function () { menu.hidden = !menu.hidden; btn.setAttribute('aria-expanded', String(!menu.hidden)); };
    botao.appendChild(btn); botao.appendChild(menu);
    (host || d.body).appendChild(botao);
  }

  /* ---------- ferramentas para o desenvolvedor ---------- */
  function seletorDe(no) {
    if (!no || no === d.body) return 'body';
    if (no.id) return '#' + (w.CSS && CSS.escape ? CSS.escape(no.id) : no.id);
    var caminho = [];
    while (no && no.nodeType === 1 && no !== d.body) {
      if (no.id) { caminho.unshift('#' + (w.CSS && CSS.escape ? CSS.escape(no.id) : no.id)); break; }
      var tag = no.tagName.toLowerCase(), pai = no.parentNode, idx = 1, irm = no;
      while ((irm = irm.previousElementSibling)) if (irm.tagName === no.tagName) idx++;
      caminho.unshift(tag + ':nth-of-type(' + idx + ')');
      no = pai;
    }
    return caminho.join(' > ');
  }

  /* Seletores para um elemento: o ID exato e, se o ID tiver prefixo de Web Component (W0003...),
     também a versão pelo fim do ID, que sobrevive à mudança de prefixo. */
  function alvoDe(no) {
    var s = seletorDe(no);
    var m = no && no.id && /^(W\d{4})+(.+)$/.exec(no.id);
    if (m) return [s, "[id$='" + m[2].replace(/'/g, "\\'") + "']"];
    m = no && no.id && /^select2-(W\d{4})+(.+)-container$/.exec(no.id);
    if (m) return [s, "[id^='select2-'][id$='" + m[2].replace(/'/g, "\\'") + "-container']"];
    return s;
  }

  // Alt+clique em qualquer controle mostra o seletor para usar no JSON.
  var mapeando = false;
  function mapear() {
    if (mapeando) return;
    mapeando = true;
    d.addEventListener('click', function (ev) {
      if (!ev.altKey || painelAutor) return;
      ev.preventDefault(); ev.stopPropagation();
      var s = seletorDe(ev.target);
      console.log('[guia-coplan] seletor:', s, ev.target);
      if (navigator.clipboard) navigator.clipboard.writeText(s).catch(function () {});
      var t = aviso('Seletor: <code></code>');
      t.querySelector('code').textContent = s;
    }, true);
    console.log('[guia-coplan] modo mapeamento ativo: Alt+clique em um controle.');
  }

  function linhasVerificacao(r, ri) {
    return r.passos.map(function (p, i) {
      var s = seletor(p.alvo);
      return { roteiro: ri + 1, passo: i + 1, titulo: p.titulo || '(sem título)', alvo: s || '(centro da tela)', encontrado: s ? !!q(s) : true, problema: !p.titulo || !p.texto ? 'falta titulo ou texto' : '' };
    });
  }

  // Lista quais alvos dos roteiros da tela não existem (use após cada build).
  function verificar() {
    if (!roteirosTela.length) { console.warn('[guia-coplan] nenhuma tela com roteiro carregada'); return []; }
    var r = [];
    roteirosTela.forEach(function (x, i) { r = r.concat(linhasVerificacao(x, i)); });
    if (console.table) console.table(r);
    return r;
  }

  /* Testa um roteiro ANTES de salvar na pasta ou no banco: cole o JSON no console.
     GuiaCoplan.testar({...})  ou  GuiaCoplan.testar('{"titulo":...}')
     Mostra a tabela de passos (alvo encontrado ou não) e já inicia o primeiro roteiro. */
  function testar(roteiro, naoIniciar) {
    var lista = interpretar(roteiro);
    if (!lista) { console.error('[guia-coplan] roteiro inválido: precisa ser JSON com "passos": [ ... ] ou "roteiros": [ ... ]'); return null; }
    var tabela = [];
    lista.forEach(function (x, i) { tabela = tabela.concat(linhasVerificacao(x, i)); });
    var faltando = tabela.filter(function (l) { return !l.encontrado; }).length;
    if (console.table) console.table(tabela);
    if (faltando) console.warn('[guia-coplan] ' + faltando + ' passo(s) com alvo que não existe nesta tela (serão pulados).');
    if (!naoIniciar) iniciarRoteiro(lista[0]);
    return tabela;
  }

  // Busca de novo o roteiro da tela atual (ex.: depois de alterar o cadastro no banco).
  function recarregar() {
    telaCarregada = null;
    carregarTela();
  }

  /* ---------- modo autor ----------
     Monta um roteiro clicando nos campos da tela (Alt+clique), escreve os textos e exporta o JSON:
     no modelo "tela a tela" o arquivo vai para a pasta roteiros/; no modelo "tabela" o JSON é
     colado no cadastro GuiaRoteiro. O rascunho fica guardado no navegador até ser descartado. */
  var painelAutor = null;
  var rascunho = null;

  function chaveRascunho() { return 'guiaCoplanRascunho:' + (telaCarregada || telaAtual()); }
  function salvarRascunho() { try { w.localStorage.setItem(chaveRascunho(), JSON.stringify(rascunho)); } catch (e) {} }

  function rotuloDe(no) {
    var t = '';
    if (no.id) { var lb = q('label[for="' + no.id.replace(/"/g, '\\"') + '"]'); if (lb) t = lb.textContent; }
    if (!t && no.closest) { var lw = no.closest('label'); if (lw) t = lw.textContent; }
    if (!t) t = no.getAttribute('aria-label') || no.getAttribute('title') || '';
    if (!t && no.closest) { var td = no.closest('td'); var ant = td && td.previousElementSibling; if (ant && !ant.querySelector('input,select,textarea,button')) t = ant.textContent; }
    if (!t) t = no.getAttribute('placeholder') || '';
    if (!t && /^(BUTTON|A)$/.test(no.tagName)) t = no.textContent;
    if (!t && no.tagName === 'INPUT' && /^(button|submit)$/i.test(no.type)) t = no.value;
    return String(t).replace(/\s+/g, ' ').replace(/[:*]\s*$/, '').trim().slice(0, 80);
  }

  function roteiroDoRascunho() {
    var r = { tela: telaCarregada, titulo: rascunho.titulo || 'Roteiro', passos: [] };
    rascunho.passos.forEach(function (p) {
      var x = {};
      if (p.alvo) x.alvo = p.alvo;
      x.titulo = p.titulo || '';
      x.texto = p.texto || '';
      if (p.lado && p.lado !== 'bottom') x.lado = p.lado;
      if (p.opcional) x.opcional = true;
      if (p.esperar) x.esperar = { tipo: p.esperar, mensagem: p.mensagem || 'Execute a ação indicada para continuar.' };
      r.passos.push(x);
    });
    return r;
  }

  function campoTexto(tag, valor, ao, ph) {
    var c = d.createElement(tag);
    c.value = valor || '';
    if (ph) c.placeholder = ph;
    c.addEventListener('input', function () { ao(c.value); salvarRascunho(); });
    return c;
  }

  function desenharAutor() {
    var lista = painelAutor.querySelector('.guia-autor__lista');
    lista.innerHTML = '';
    if (!rascunho.passos.length) {
      lista.appendChild(el('div', 'guia-autor__vazio', 'Segure <b>Alt</b> e clique em um campo da tela para adicionar o primeiro passo.'));
    }
    rascunho.passos.forEach(function (p, i) {
      var item = el('div', 'guia-autor__passo');
      var topo = el('div', 'guia-autor__topo');
      topo.appendChild(el('span', 'guia-autor__num', String(i + 1)));
      var alvoTxt = el('code', 'guia-autor__alvo');
      alvoTxt.textContent = p.alvo ? (ehLista(p.alvo) ? p.alvo[0] : p.alvo) : '(mensagem no centro da tela)';
      topo.appendChild(alvoTxt);
      [['↑', -1], ['↓', 1]].forEach(function (b) {
        var bt = el('button', 'guia-autor__mini'); bt.type = 'button'; bt.textContent = b[0];
        bt.setAttribute('aria-label', b[1] < 0 ? 'Subir passo' : 'Descer passo');
        bt.onclick = function () { var j = i + b[1]; if (j < 0 || j >= rascunho.passos.length) return; var t = rascunho.passos[i]; rascunho.passos[i] = rascunho.passos[j]; rascunho.passos[j] = t; salvarRascunho(); desenharAutor(); };
        topo.appendChild(bt);
      });
      var rm = el('button', 'guia-autor__mini'); rm.type = 'button'; rm.textContent = '×'; rm.setAttribute('aria-label', 'Remover passo');
      rm.onclick = function () { rascunho.passos.splice(i, 1); salvarRascunho(); desenharAutor(); };
      topo.appendChild(rm);
      item.appendChild(topo);
      item.appendChild(campoTexto('input', p.titulo, function (v) { p.titulo = v; }, 'Título do balão'));
      item.appendChild(campoTexto('textarea', p.texto, function (v) { p.texto = v; }, 'O que o usuário deve fazer e por quê'));
      var opcoes = el('div', 'guia-autor__opcoes');
      var sel = d.createElement('select');
      [['', 'Não esperar ação'], ['preenchido', 'Esperar preencher'], ['marcado', 'Esperar marcar'], ['clique', 'Esperar clicar']].forEach(function (o) {
        var op = d.createElement('option'); op.value = o[0]; op.textContent = o[1]; if ((p.esperar || '') === o[0]) op.selected = true; sel.appendChild(op);
      });
      sel.onchange = function () { p.esperar = sel.value || null; salvarRascunho(); };
      opcoes.appendChild(sel);
      var lb = d.createElement('label'); var ck = d.createElement('input'); ck.type = 'checkbox'; ck.checked = !!p.opcional;
      ck.onchange = function () { p.opcional = ck.checked; salvarRascunho(); };
      lb.appendChild(ck); lb.appendChild(d.createTextNode(' Opcional'));
      opcoes.appendChild(lb);
      item.appendChild(opcoes);
      lista.appendChild(item);
    });
  }

  function cliqueAutor(ev) {
    if (!painelAutor || !ev.altKey) return;
    if (painelAutor.contains(ev.target)) return;
    ev.preventDefault(); ev.stopPropagation();
    var no = ev.target.closest('input,select,textarea,button,a,[id]') || ev.target;
    rascunho.passos.push({ alvo: alvoDe(no), titulo: rotuloDe(no), texto: '', esperar: null, opcional: false });
    salvarRascunho(); desenharAutor();
    var lista = painelAutor.querySelector('.guia-autor__lista');
    lista.scrollTop = lista.scrollHeight;
  }

  function baixarArquivo(nome, conteudo) {
    var a = d.createElement('a');
    a.href = URL.createObjectURL(new Blob([conteudo], { type: 'application/json' }));
    a.download = nome; d.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  }

  function autor() {
    if (painelAutor) return painelAutor;
    if (driverObj && driverObj.isActive()) driverObj.destroy();
    if (!telaCarregada) telaCarregada = telaAtual();
    try { rascunho = JSON.parse(w.localStorage.getItem(chaveRascunho()) || 'null'); } catch (e) { rascunho = null; }
    if (!rascunho || !ehLista(rascunho.passos)) {
      rascunho = { titulo: '', passos: [] };
      // começa a partir do roteiro que a tela já tem, se houver
      var base = roteirosTela[0];
      if (base) {
        rascunho.titulo = base.titulo || '';
        rascunho.passos = base.passos.map(function (p) {
          return { alvo: p.alvo || null, titulo: p.titulo || '', texto: p.texto || '', lado: p.lado, opcional: !!p.opcional, esperar: p.esperar ? p.esperar.tipo : null, mensagem: p.esperar ? p.esperar.mensagem : '' };
        });
      }
    }
    painelAutor = el('div', 'guia-autor');
    painelAutor.setAttribute('role', 'dialog');
    painelAutor.setAttribute('aria-label', 'Criar roteiro desta tela');
    var cab = el('div', 'guia-autor__cab');
    var tit = el('div', 'guia-autor__titulo'); tit.textContent = 'Criar roteiro · ' + telaCarregada;
    var lado = el('button', 'guia-autor__mini'); lado.type = 'button'; lado.textContent = '⇆'; lado.title = 'Mudar o painel de lado';
    lado.setAttribute('aria-label', 'Mudar o painel de lado');
    lado.onclick = function () { painelAutor.classList.toggle('guia-autor--direita'); };
    var mini = el('button', 'guia-autor__mini'); mini.type = 'button'; mini.textContent = '–'; mini.title = 'Recolher';
    mini.setAttribute('aria-label', 'Recolher ou expandir o painel');
    mini.onclick = function () { painelAutor.classList.toggle('guia-autor--recolhido'); };
    var fechar = el('button', 'guia-autor__mini'); fechar.type = 'button'; fechar.textContent = '×'; fechar.setAttribute('aria-label', 'Fechar modo autor');
    fechar.onclick = fecharAutor;
    var acoesCab = el('div', 'guia-autor__acoes-cab');
    acoesCab.appendChild(lado); acoesCab.appendChild(mini); acoesCab.appendChild(fechar);
    cab.appendChild(tit); cab.appendChild(acoesCab);
    painelAutor.appendChild(cab);
    painelAutor.appendChild(campoTexto('input', rascunho.titulo, function (v) { rascunho.titulo = v; }, 'Nome do roteiro (ex.: Emitir NFS-e)'));
    var centro = el('button', 'guia-autor__link'); centro.type = 'button'; centro.textContent = '+ Passo sem campo (mensagem no centro)';
    centro.onclick = function () { rascunho.passos.push({ alvo: null, titulo: '', texto: '', esperar: null, opcional: false }); salvarRascunho(); desenharAutor(); };
    painelAutor.appendChild(centro);
    painelAutor.appendChild(el('div', 'guia-autor__lista'));
    var rod = el('div', 'guia-autor__rodape');
    var bTestar = el('button', 'guia-autor__acao guia-autor__acao--primaria'); bTestar.type = 'button'; bTestar.textContent = 'Testar';
    bTestar.onclick = function () {
      if (!rascunho.passos.length) return aviso('Adicione pelo menos um passo.');
      painelAutor.style.display = 'none';
      aoTerminar = function () { if (painelAutor) painelAutor.style.display = ''; };
      testar(roteiroDoRascunho());
    };
    var bCopiar = el('button', 'guia-autor__acao'); bCopiar.type = 'button'; bCopiar.textContent = 'Copiar JSON';
    bCopiar.onclick = function () {
      var txt = JSON.stringify(roteiroDoRascunho(), null, 2);
      if (navigator.clipboard) navigator.clipboard.writeText(txt).then(function () { aviso('JSON copiado. Cole no cadastro GuiaRoteiro ou salve como ' + telaCarregada + '.json'); }, function () { console.log(txt); aviso('Não deu para copiar: o JSON foi escrito no console.'); });
      else { console.log(txt); aviso('O JSON foi escrito no console.'); }
    };
    var bBaixar = el('button', 'guia-autor__acao'); bBaixar.type = 'button'; bBaixar.textContent = 'Baixar .json';
    bBaixar.onclick = function () { baixarArquivo(telaCarregada + '.json', JSON.stringify(roteiroDoRascunho(), null, 2)); };
    var bLimpar = el('button', 'guia-autor__acao guia-autor__acao--perigo'); bLimpar.type = 'button'; bLimpar.textContent = 'Limpar';
    bLimpar.onclick = function () {
      if (!w.confirm('Apagar todos os passos do rascunho desta tela?')) return;
      rascunho.passos = []; salvarRascunho(); desenharAutor();
    };
    [bTestar, bCopiar, bBaixar, bLimpar].forEach(function (b) { rod.appendChild(b); });
    painelAutor.appendChild(rod);
    d.body.appendChild(painelAutor);
    d.addEventListener('click', cliqueAutor, true);
    desenharAutor();
    registrar('autor_aberto');
    return painelAutor;
  }

  function fecharAutor() {
    if (!painelAutor) return;
    d.removeEventListener('click', cliqueAutor, true);
    painelAutor.remove(); painelAutor = null;
  }

  /* ---------- manual automático ----------
     Monta o manual da tela na hora em que o usuário pede, com três fontes, nesta ordem:
       1. o bloco opcional "ajuda" do JSON (objetivo, antes de começar, regras, perguntas frequentes),
          escrito por quem conhece o processo, no mesmo arquivo ou cadastro do roteiro;
       2. os textos dos roteiros da tela (passo a passo);
       3. a própria tela: grupos, campos, tipo, obrigatoriedade e botões, lidos do HTML.
     Ninguém precisa alimentar um lugar separado. Se existir um manual escrito (manualUrl),
     o menu também oferece "Manual completo". */
  var painelManual = null;

  function visivel(e) {
    if (!e || !(e.offsetWidth || e.offsetHeight || e.getClientRects().length)) return false;
    var cs = w.getComputedStyle(e); return cs.visibility !== 'hidden' && cs.display !== 'none';
  }
  function ignorado(e) { try { return !!(CFG.manualIgnorar && e.closest(CFG.manualIgnorar)); } catch (x) { return false; } }
  function limpo(t) { return String(t || '').replace(/\s+/g, ' ').replace(/\s*[:*]\s*$/, '').trim(); }

  // passo de roteiro que aponta para o elemento (para aproveitar o texto como orientação do campo)
  function passoDoCampo(e) {
    for (var i = 0; i < roteirosTela.length; i++) {
      var ps = roteirosTela[i].passos;
      for (var k = 0; k < ps.length; k++) {
        var p = ps[k], s = seletor(p.alvo), alvo = s && q(s);
        if (alvo && (alvo === e || (alvo.contains && alvo.contains(e)))) return p;
        var es = p.esperar && seletor(p.esperar.alvo), ae = es && q(es);
        if (ae && ae === e) return p;
      }
    }
    return null;
  }

  // Lê a tela: devolve { grupos: [{ titulo, campos: [...] }], botoes: [...] }
  function lerTela() {
    var raiz = (CFG.manualRaiz && q(CFG.manualRaiz)) || d.body;
    var grupos = [], porTitulo = {}, botoes = [], vistos = [];
    function grupoDe(e) {
      var fs = e.closest && e.closest('fieldset');
      var t = fs && fs.querySelector('legend') ? limpo(fs.querySelector('legend').textContent) : 'Campos';
      if (!porTitulo[t]) { porTitulo[t] = { titulo: t, campos: [] }; grupos.push(porTitulo[t]); }
      return porTitulo[t];
    }
    [].forEach.call(raiz.querySelectorAll('input, select, textarea'), function (e) {
      var tipo = (e.type || '').toLowerCase();
      if (tipo === 'hidden' || ignorado(e)) return;
      if (/^(button|submit|reset|image)$/.test(tipo)) { if (visivel(e)) botoes.push({ nome: limpo(e.value || rotuloDe(e)), id: e.id }); return; }
      if (!visivel(e) && !(e.closest && e.closest('.select2-container'))) {
        // select escondido pelo Select2 continua valendo: o usuário vê o container
        if (!(e.tagName === 'SELECT' && e.nextElementSibling && /select2/.test(e.nextElementSibling.className || ''))) return;
      }
      if (tipo === 'radio' && e.name) { if (vistos.indexOf('radio:' + e.name) >= 0) return; vistos.push('radio:' + e.name); }
      var nome = rotuloDe(e) || e.name || e.id;
      var lb = e.id && q('label[for="' + e.id.replace(/"/g, '\\"') + '"]');
      var rotuloBruto = (lb ? lb.textContent : '') + ' ' + (e.closest && e.closest('label') ? e.closest('label').textContent : '');
      var p = passoDoCampo(e);
      var obrig = e.required || e.getAttribute('aria-required') === 'true' || /\*/.test(rotuloBruto) ||
                  /required|obrigat/i.test(e.className || '') || !!(p && p.esperar && p.esperar.tipo === 'preenchido');
      var t;
      if (e.readOnly || e.disabled) t = 'Preenchido pelo sistema';
      else if (e.tagName === 'SELECT') {
        var ops = [].filter.call(e.options, function (o) { return o.value !== ''; }).map(function (o) { return limpo(o.textContent); });
        t = 'Lista de opções' + (ops.length ? ' (' + ops.slice(0, 4).join('; ') + (ops.length > 4 ? '; ...' : '') + ')' : '');
      }
      else if (tipo === 'checkbox') t = 'Marcar se aplicável';
      else if (tipo === 'radio') t = 'Escolher uma opção';
      else if (e.tagName === 'TEXTAREA') t = 'Texto livre';
      else if (/^(date|datetime-local)$/.test(tipo)) t = 'Data';
      else if (tipo === 'email') t = 'E-mail';
      else if (/^(number)$/.test(tipo)) t = 'Número';
      else t = 'Digitação' + (e.placeholder ? ' (ex.: ' + limpo(e.placeholder) + ')' : '');
      if (e.parentNode && e.parentNode.querySelector && e.parentNode.querySelector('a.gx-image-link')) t += ', com lupa de consulta';
      grupoDe(e).campos.push({ nome: limpo(nome), tipo: t, obrigatorio: !!obrig && !(e.readOnly || e.disabled), orientacao: p ? (p.texto || '') : '', opcional: !!(p && p.opcional), id: e.id });
    });
    [].forEach.call(raiz.querySelectorAll('button, a.btn, a[role=button]'), function (e) {
      if (ignorado(e) || !visivel(e) || e.classList.contains('gx-image-link')) return;
      var nome = limpo(e.textContent || e.getAttribute('aria-label') || e.title);
      if (nome) botoes.push({ nome: nome, id: e.id });
    });
    botoes.forEach(function (b) { var p = b.id && passoDoCampo(q('#' + (w.CSS && CSS.escape ? CSS.escape(b.id) : b.id))); b.orientacao = p ? (p.texto || '') : ''; });
    return { tela: telaCarregada || telaAtual(), grupos: grupos.filter(function (g) { return g.campos.length; }), botoes: botoes };
  }

  function seco(tag, cls, txt) { var e = d.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; }
  function rico(tag, cls, html) { var e = d.createElement(tag); if (cls) e.className = cls; e.innerHTML = textoSeguro(html); return e; }

  function manual() {
    fecharManual();
    if (driverObj && driverObj.isActive()) driverObj.destroy();
    var dados = lerTela(), ajuda = roteirosTela.ajuda || {}, r0 = roteirosTela[0];
    painelManual = el('div', 'guia-manual');
    painelManual.setAttribute('role', 'dialog'); painelManual.setAttribute('aria-label', 'Manual desta tela');
    var cab = el('div', 'guia-manual__cab');
    var tit = el('div', 'guia-manual__titulos');
    tit.appendChild(seco('div', 'guia-manual__eyebrow', 'Manual desta tela'));
    tit.appendChild(seco('h2', 'guia-manual__titulo', ajuda.titulo || (r0 && (r0.macroprocesso || r0.titulo)) || dados.tela));
    tit.appendChild(seco('div', 'guia-manual__meta', 'Tela ' + dados.tela + ' · gerado automaticamente em ' + new Date().toLocaleString('pt-BR')));
    cab.appendChild(tit);
    var acoes = el('div', 'guia-manual__acoes');
    var bImp = seco('button', 'guia-manual__btn', 'Imprimir ou salvar PDF'); bImp.type = 'button';
    bImp.onclick = function () { d.body.classList.add('guia-imprimindo'); setTimeout(function () { w.print(); d.body.classList.remove('guia-imprimindo'); }, 50); registrar('manual_impresso'); };
    acoes.appendChild(bImp);
    if (CFG.manualUrl || CFG.onAbrirManual) { var bC = seco('button', 'guia-manual__btn', 'Manual completo'); bC.type = 'button'; bC.onclick = abrirManual; acoes.appendChild(bC); }
    var bF = seco('button', 'guia-manual__fechar', '×'); bF.type = 'button'; bF.setAttribute('aria-label', 'Fechar manual'); bF.onclick = fecharManual;
    acoes.appendChild(bF);
    cab.appendChild(acoes);
    painelManual.appendChild(cab);
    var corpo = el('div', 'guia-manual__corpo');
    function secao(t) { var s = el('section', 'guia-manual__secao'); s.appendChild(seco('h3', null, t)); corpo.appendChild(s); return s; }
    if (ajuda.objetivo) secao('Para que serve').appendChild(rico('p', null, ajuda.objetivo));
    if (ehLista(ajuda.antes) && ajuda.antes.length) { var sa = secao('Antes de começar'), ul = el('ul'); ajuda.antes.forEach(function (x) { ul.appendChild(rico('li', null, x)); }); sa.appendChild(ul); }
    roteirosTela.forEach(function (r) {
      var s = secao('Passo a passo: ' + (r.titulo || 'roteiro')), ol = el('ol');
      r.passos.forEach(function (p) {
        if (!p.alvo) { s.insertBefore(rico('p', 'guia-manual__intro', p.texto), s.children[1] || null); return; }
        var li = el('li'); li.appendChild(rico('b', null, p.titulo)); if (p.opcional) li.appendChild(seco('span', 'guia-manual__selo', 'opcional'));
        li.appendChild(d.createTextNode(' ')); li.appendChild(rico('span', null, p.texto)); ol.appendChild(li);
      });
      s.appendChild(ol);
      var bt = seco('button', 'guia-manual__link', 'Fazer este passo a passo na tela'); bt.type = 'button';
      bt.onclick = function () { fecharManual(); iniciarRoteiro(r); }; s.appendChild(bt);
    });
    if (!roteirosTela.length && CFG.roteiroAuto) {
      var ra = roteiroAutomatico(true), sa2 = secao('Passo a passo: campos obrigatórios'), ol2 = el('ol');
      ra.passos.slice(1).forEach(function (p) { var li = el('li'); li.appendChild(seco('b', null, p.titulo)); li.appendChild(d.createTextNode(' ' + p.texto)); ol2.appendChild(li); });
      sa2.appendChild(ol2);
      var bt2 = seco('button', 'guia-manual__link', 'Fazer este passo a passo na tela'); bt2.type = 'button';
      bt2.onclick = function () { fecharManual(); iniciarRoteiro('auto:o'); }; sa2.appendChild(bt2);
    }
    var sc = secao('Campos da tela');
    if (!dados.grupos.length) sc.appendChild(seco('p', null, 'Nenhum campo encontrado nesta tela.'));
    dados.grupos.forEach(function (g) {
      if (dados.grupos.length > 1 || g.titulo !== 'Campos') sc.appendChild(seco('h4', null, g.titulo));
      var tb = el('table', 'guia-manual__tabela'), th = el('tr');
      ['Campo', 'Como preencher', 'Obrigatório'].forEach(function (x) { th.appendChild(seco('th', null, x)); });
      var thead = el('thead'); thead.appendChild(th); tb.appendChild(thead);
      var tbody = el('tbody');
      g.campos.forEach(function (c) {
        var tr = el('tr'); tr.appendChild(seco('td', null, c.nome));
        var td = el('td'); td.appendChild(seco('span', 'guia-manual__tipo', c.tipo)); if (c.orientacao) { td.appendChild(d.createElement('br')); td.appendChild(rico('span', null, c.orientacao)); } tr.appendChild(td);
        tr.appendChild(seco('td', null, c.obrigatorio ? 'Sim' : (c.opcional ? 'Não (opcional)' : 'Não')));
        tbody.appendChild(tr);
      });
      tb.appendChild(tbody); sc.appendChild(tb);
    });
    if (dados.botoes.length) { var sb = secao('Botões'), ub = el('ul'); dados.botoes.forEach(function (b) { var li = el('li'); li.appendChild(seco('b', null, b.nome)); if (b.orientacao) { li.appendChild(d.createTextNode(': ')); li.appendChild(rico('span', null, b.orientacao)); } ub.appendChild(li); }); sb.appendChild(ub); }
    if (ehLista(ajuda.regras) && ajuda.regras.length) { var sr = secao('Regras importantes'), ur = el('ul'); ajuda.regras.forEach(function (x) { ur.appendChild(rico('li', null, x)); }); sr.appendChild(ur); }
    if (ehLista(ajuda.perguntas) && ajuda.perguntas.length) { var sp = secao('Perguntas frequentes'); ajuda.perguntas.forEach(function (x) { sp.appendChild(rico('p', 'guia-manual__pergunta', x.p || x.pergunta || '')); sp.appendChild(rico('p', null, x.r || x.resposta || '')); }); }
    corpo.appendChild(seco('p', 'guia-manual__rodape', 'Manual gerado a partir da tela e dos roteiros' + (ajuda.objetivo || ajuda.regras ? ', com as orientações cadastradas' : '') + '. Regras de negócio que não estejam aqui constam no manual completo' + (CFG.manualUrl ? '.' : ' do sistema.')));
    painelManual.appendChild(corpo);
    d.body.appendChild(painelManual);
    bF.focus();
    registrar('manual_aberto', { origem: 'automatico' });
    return dados;
  }

  /* ---------- passo a passo automático ----------
     Gerado da própria tela, sem roteiro escrito: percorre os campos visíveis na ordem em que
     aparecem, com o rótulo de cada um como título e um texto conforme o tipo. Campo obrigatório
     espera ser preenchido; os demais são opcionais. Se a tela tiver roteiro escrito (pasta ou
     tabela), ele aparece no menu antes do automático. */
  function itensDaTela() {
    var raiz = (CFG.manualRaiz && q(CFG.manualRaiz)) || d.body, itens = [], radios = [];
    [].forEach.call(raiz.querySelectorAll('input, select, textarea, button, a.btn, a[role=button]'), function (e) {
      if (ignorado(e)) return;
      var tipo = (e.type || '').toLowerCase();
      if (tipo === 'hidden' || (e.classList && e.classList.contains('gx-image-link'))) return;
      var botao = e.tagName === 'BUTTON' || e.tagName === 'A' || /^(button|submit|reset|image)$/.test(tipo);
      var s2 = e.tagName === 'SELECT' && e.id && q('#select2-' + (w.CSS && CSS.escape ? CSS.escape(e.id) : e.id) + '-container');
      if (!visivel(e) && !(s2 && visivel(s2))) return;
      if (tipo === 'radio' && e.name) { if (radios.indexOf(e.name) >= 0) return; radios.push(e.name); }
      var nome = limpo(botao ? (e.value && e.tagName === 'INPUT' ? e.value : e.textContent) || rotuloDe(e) : rotuloDe(e) || e.name || e.id);
      if (!nome) return;
      var lb = e.id && q('label[for="' + e.id.replace(/"/g, '\\"') + '"]');
      var bruto = (lb ? lb.textContent : '') + ' ' + (e.closest && e.closest('label') ? e.closest('label').textContent : '');
      itens.push({ el: e, s2: s2 || null, nome: nome, botao: botao, tipo: tipo,
        somenteLeitura: !botao && (e.readOnly || e.disabled),
        obrigatorio: !botao && !(e.readOnly || e.disabled) && (e.required || e.getAttribute('aria-required') === 'true' || /\*/.test(bruto) || /required|obrigat/i.test(e.className || '')),
        lupa: !!(e.parentNode && e.parentNode.querySelector && e.parentNode.querySelector('a.gx-image-link')) });
    });
    return itens;
  }

  function roteiroAutomatico(soObrigatorios) {
    var itens = itensDaTela(), passos = [], ultimoCampo = -1;
    itens.forEach(function (it, i) { if (!it.botao) ultimoCampo = i; });
    passos.push({ titulo: soObrigatorios ? 'Campos obrigatórios desta tela' : 'Todos os campos desta tela',
      texto: 'Passo a passo gerado automaticamente a partir da tela. ' + (soObrigatorios ? 'Mostra só o que precisa ser preenchido e o botão final.' : 'Campos obrigatórios esperam o preenchimento; os demais são opcionais.') });
    itens.forEach(function (it, i) {
      if (soObrigatorios && !it.obrigatorio && !(it.botao && i > ultimoCampo)) return;
      var alvo = it.s2 ? [].concat(alvoDe(it.s2), alvoDe(it.el)) : alvoDe(it.el);
      var n = it.nome, t;
      if (it.botao) t = i > ultimoCampo ? 'Quando os dados estiverem prontos, use o botão ' + n + '.' : 'Botão ' + n + '.';
      else if (it.somenteLeitura) t = 'Preenchido pelo sistema. Confira o valor.';
      else if (it.el.tagName === 'SELECT') t = 'Selecione ' + n + ' na lista.';
      else if (it.tipo === 'checkbox') t = 'Marque esta opção se ela se aplicar.';
      else if (it.tipo === 'radio') t = 'Escolha uma das opções.';
      else if (it.el.tagName === 'TEXTAREA') t = 'Descreva: ' + n + '.';
      else t = 'Informe ' + n + '.' + (it.el.placeholder && !/opcional/i.test(it.el.placeholder) ? ' Exemplo de formato: ' + limpo(it.el.placeholder) + '.' : '');
      if (it.lupa) t += ' Se não souber o valor, use a lupa para consultar.';
      var p = { alvo: alvo, titulo: n, texto: t };
      if (it.obrigatorio && it.tipo !== 'checkbox' && it.tipo !== 'radio') p.esperar = { tipo: 'preenchido', alvo: alvoDe(it.el), mensagem: 'Campo obrigatório: informe ' + n + ' para continuar.' };
      else if (!it.botao && !it.obrigatorio) p.opcional = true;
      passos.push(p);
    });
    return { titulo: soObrigatorios ? 'Campos obrigatórios (automático)' : 'Todos os campos (automático)', automatico: true, passos: passos };
  }
  function fecharManual() { if (painelManual) { painelManual.remove(); painelManual = null; } }
  d.addEventListener('keydown', function (ev) { if (ev.key === 'Escape' && painelManual && !(driverObj && driverObj.isActive())) fecharManual(); });

  /* ---------- ciclo de vida ---------- */
  function carregarTela() {
    var tela = telaAtual();
    if (tela === telaCarregada) return;
    telaCarregada = tela;
    carregarRoteiros(tela).then(function (lista) {
      roteirosTela = lista || [];
      roteiroAtual = roteirosTela[0] || null;
      log('tela', tela, roteirosTela.length + ' roteiro(s)');
      montarBotao();
      var est = lerEstado();
      var podeRetomar = est && (roteirosTela[est.roteiro] || (CFG.roteiroAuto && /^auto:/.test(String(est.roteiro))));
      if (podeRetomar && !(driverObj && driverObj.isActive())) {
        aviso('Continuando o roteiro de onde você parou.', 2500);
        iniciarRoteiro(est.roteiro, est.passo);
      }
    });
  }

  var iniciado = false;
  function iniciar(config) {
    CFG = {};
    for (var k in PADRAO) CFG[k] = PADRAO[k];
    var ext = config || w.GUIA_COPLAN_CONFIG || {};
    for (var j in ext) CFG[j] = ext[j];
    if (iniciado) { recarregar(); return; }
    iniciado = true;

    d.addEventListener('click', ouvirAcoes, true);
    d.addEventListener('change', ouvirAcoes, true);
    d.addEventListener('input', ouvirAcoes, true);

    // Reposiciona o destaque quando o GeneXus atualiza a tela via AJAX.
    if (w.MutationObserver && !observador) {
      var t = null;
      observador = new MutationObserver(function () {
        clearTimeout(t);
        t = setTimeout(function () { if (driverObj && driverObj.isActive()) { reposicionar(); driverObj.refresh(); atualizarPopover(); } }, 150);
      });
      observador.observe(d.body, { childList: true, subtree: true });
    }

    // Vigia a posição do campo destacado: se ela mudar (scroll, resize, CSS, campo que cresce),
    // recalcula destaque e popover. Evita o popover "perdido" no canto da tela.
    var ultimaPos = '';
    // Popup de consulta do GeneXus (lupa): é um iframe grande e visível. Enquanto ele estiver aberto,
    // o guia se pausa (overlay e popover somem, tudo fica clicável) e volta quando o popup fecha.
    function popupAberto() {
      var fr = qa('iframe');
      for (var k = 0; k < fr.length; k++) {
        if (fr[k].offsetWidth > 150 && fr[k].offsetHeight > 150) return true;
      }
      return false;
    }
    function reposicionar() {
      var ativo = !!(driverObj && driverObj.isActive());
      var pausar = ativo && popupAberto();
      var estavaPausado = d.body.classList.contains('guia-pausado');
      d.body.classList.toggle('guia-pausado', pausar);
      if (pausar) return;
      if (estavaPausado && ativo) { ultimaPos = ''; driverObj.refresh(); atualizarPopover(); }
      if (!ativo) {
        ultimaPos = '';
        // rede de segurança: se o Driver.js encerrar sem chamar onDestroyed (ex.: Esc durante a
        // animação de entrada), faz a limpeza que o onDestroyed faria
        if (driverObj) { driverObj = null; limparEstado(); if (typeof aoTerminar === 'function') { var f = aoTerminar; aoTerminar = null; f(); } }
        return;
      }
      var i = driverObj.getActiveIndex();
      var p = roteiroAtual && roteiroAtual.passos[i];
      var e = p && p.alvo ? resolverAlvo(p.alvo) : null;
      if (!e) return;
      // O GeneXus recria o controle após um evento (ex.: escolher item do dropdown):
      // o Driver.js fica com o elemento antigo, fora da página. Destaca o passo de novo.
      var destacado = driverObj.getActiveElement && driverObj.getActiveElement();
      if (destacado && destacado !== e) { ultimaPos = ''; driverObj.moveTo(i); return; }
      var r = e.getBoundingClientRect();
      var pos = [r.top, r.left, r.width, r.height, w.pageYOffset, w.pageXOffset].map(Math.round).join(',');
      if (pos !== ultimaPos) { ultimaPos = pos; driverObj.refresh(); }
    }
    setInterval(reposicionar, 250);
    w.addEventListener('resize', reposicionar);
    w.addEventListener('scroll', reposicionar, true);

    // Web User Experience "Smooth" pode trocar de tela sem recarregar a página.
    setInterval(carregarTela, 1000);
    try { if (w.localStorage && localStorage.getItem('guiaCoplanMapear') === '1') mapear(); } catch (e) {}
    carregarTela();
    try { if (w.localStorage && localStorage.getItem('guiaCoplanAutor') === '1') setTimeout(autor, 300); } catch (e) {}
  }

  w.GuiaCoplan = {
    versao: VERSAO,
    iniciar: iniciar,
    iniciarRoteiro: iniciarRoteiro,
    telaAtual: telaAtual,
    roteiros: function () { return roteirosTela.slice(); },
    mapear: mapear,
    verificar: verificar,
    testar: testar,
    recarregar: recarregar,
    autor: autor,
    manual: manual,
    roteiroAutomatico: function (o) { return JSON.parse(JSON.stringify(roteiroAutomatico(!!o))); },
    fecharManual: fecharManual,
    lerTela: lerTela,
    fecharAutor: fecharAutor
  };

  if (w.GUIA_COPLAN_CONFIG && w.GUIA_COPLAN_CONFIG.autoIniciar !== false) {
    if (d.readyState === 'loading') d.addEventListener('DOMContentLoaded', function () { iniciar(); });
    else iniciar();
  }
})(window, document);
