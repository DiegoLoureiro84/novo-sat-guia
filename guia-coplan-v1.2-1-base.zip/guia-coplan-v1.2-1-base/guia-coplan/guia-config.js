/* Guia Coplan v1.2 · configuração BASE (automática, ninguém precisa escrever nada).
   Carregar ANTES do guia-coplan.js. As opções de escrita (pasta ou tabela) só mudam roteirosUrl. */
window.GUIA_COPLAN_CONFIG = {
  // Passo a passo automático: gerado da própria tela (campos obrigatórios ou todos os campos).
  roteiroAuto: true,
  // Manual automático: montado na hora, lendo a tela (e os roteiros escritos, se houver).
  manualAuto: true,
  // Área da página que o guia lê. Indique o conteúdo da Master Page para não listar o menu e o
  // cabeçalho do sistema (ex.: '#MAINFORM' ou o id do content placeholder). null = página toda.
  manualRaiz: null,

  // Roteiros escritos: NENHUM na base. As opções 2 (pasta) e 3 (tabela) preenchem esta linha.
  roteirosUrl: [],

  // Manual escrito externo (opcional, só se já existir um). Se preenchido, o menu mostra "Manual completo".
  manualUrl: null,

  autor: false,          // true só em desenvolvimento/homologação: mostra "Criar roteiro desta tela"
  montarBotaoEm: null,   // seletor para pôr o botão "?" no cabeçalho; null = botão flutuante
  retomarMinutos: 2,     // se a tela recarregar (postback) nesse prazo, o passo a passo continua
  debug: false
};
