/* Guia Coplan v1.2 · configuração com a OPÇÃO 2 (roteiros e ajuda escritos em arquivos .json).
   Substitui o guia-config.js da base. Tudo o que é automático continua funcionando. */
window.GUIA_COPLAN_CONFIG = {
  roteiroAuto: true,
  manualAuto: true,
  manualRaiz: null,     // conteúdo da Master Page (ver LEIA-ME da base)

  // Pasta dos roteiros escritos. Caminho absoluto a partir do host (começa com /).
  // O guia busca <pasta><nome da tela>.json. Tela sem arquivo continua com o automático.
  roteirosUrl: '/tributario/static/guia-coplan/roteiros/',

  manualUrl: null,
  autor: false,
  montarBotaoEm: null,
  retomarMinutos: 2,
  debug: false
};
