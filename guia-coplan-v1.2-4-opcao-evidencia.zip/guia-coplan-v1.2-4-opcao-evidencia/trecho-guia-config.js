/* OPÇÃO 4 · evidência de uso. Acrescentar dentro de window.GUIA_COPLAN_CONFIG, em qualquer das
   configurações (base, pasta ou tabela). Conferir a URL real do Procedure GuiaEventoRegistrar. */
  registrar: function (evento) {
    try { navigator.sendBeacon('/tributario/servlet/com.tributario.aguiaeventoregistrar', JSON.stringify(evento)); } catch (e) {}
  },
