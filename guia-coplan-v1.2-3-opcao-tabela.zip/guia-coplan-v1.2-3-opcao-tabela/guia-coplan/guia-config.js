/* Guia Coplan v1.2 · configuração com a OPÇÃO 3 (roteiros e ajuda escritos em tabela do banco).
   Substitui o guia-config.js da base. Tudo o que é automático continua funcionando. */
window.GUIA_COPLAN_CONFIG = {
  roteiroAuto: true,
  manualAuto: true,
  manualRaiz: null,     // conteúdo da Master Page (ver LEIA-ME da base)

  // Tenta na ordem e usa o primeiro que responder. {tela} é trocado pelo nome da tela.
  roteirosUrl: [
    // 1) Procedure GuiaRoteiroObter (conferir a URL real gerada pelo GeneXus)
    '/tributario/servlet/com.tributario.aguiaroteiroobter?tela={tela}',
    // 2) Pasta, opcional: útil durante a migração da opção 2 para a 3. Pode apagar esta linha.
    '/tributario/static/guia-coplan/roteiros/'
  ],

  manualUrl: null,
  autor: false,
  montarBotaoEm: null,
  retomarMinutos: 2,
  debug: false
};
